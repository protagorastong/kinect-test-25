// JavaScript source code
var K2 = require('kinect2'),
    express = require('express'),
    app = express(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server);

var kinect = new K2();
var count = 0;


function mode(ary) {
    var counter = {};
    var mode = [];
    var max = 0;
    for (var i in ary) {
        if (!(ary[i] in counter))
            counter[ary[i]] = 0;
        counter[ary[i]]++;
 
        if (counter[ary[i]] == max) 
            mode.push(ary[i]);
        else if (counter[ary[i]] > max) {
            max = counter[ary[i]];
            mode = [ary[i]];
        }
    }
    return mode[0]; 
}

function mean(array) {
  return array.reduce(function (a, b) {
    return a + b;
  }) / array.length;
}

if (kinect.open()) {
    server.listen(8888);
    console.log('Kinect Depth Sensor On.\nScripts Last Update:'+
    	'\n2018-03-02\nPorting to localhost:8888');

    // app.get('/', function (req, res) {
    //     res.sendFile(__dirname + '/index.html');
    // });
    let count = 0;
    let avgDepthFrame = new Array(217088).fill(0);

    kinect.on('depthFrame', function (depthFrame) {
        count += 1;
        if (count == 1){
            frame_1 = new Uint16Array(depthFrame);
        }
        else if(count == 2){
            frame_2 = new Uint16Array(depthFrame);
        }
        else if(count == 3){
            frame_3 = new Uint16Array(depthFrame);
        }
        // else if(count == 4){
        //     frame_4 = new Uint16Array(depthFrame);
        // }
        // else if(count == 5){
        //     frame_5 = new Uint16Array(depthFrame);
        // }
        // else if(count == 6){
        //     frame_6 = new Uint16Array(depthFrame);
        // }
        // else if(count == 7){
        //     frame_7 = new Uint16Array(depthFrame);
        // }
        // else if(count == 8){
        //     frame_8 = new Uint16Array(depthFrame);
        // }
        if (count == 3){
            for (let i=0; i<avgDepthFrame.length; i++){
                var ary = [frame_1[i],frame_2[i],frame_3[i]];
                avgDepthFrame[i] = Math.min.apply(null, ary);
            }
            io.sockets.emit('depthFrame', avgDepthFrame);
            count = 0;
        }
    });
    kinect.openDepthReader();
}